# ACE NADI text motions for Canva

Every clip is a full 1920×1080 frame with a transparent background. Each element already sits where it appears in the film.

## Files

| Type | What it is |
|---|---|
| `*.webm` | Animated clips: VP9 video with an alpha channel, 30 fps |
| `*.png` | The fully built-in frame of each clip, for static designs, thumbnails or detail-page images |
| `scrim_left.png`, `scrim_right.png`, `scrim_center.png` | Soft white light pools placed behind the text in the film. They keep the purple text readable on busy footage. |
| `end_card_background.png` | Lavender gradient behind the end card |

## Using them in Canva
1. Upload the `.webm` files (Uploads → Upload files).
2. Drag a clip onto your video page.
3. Resize it to fill the page: right-click the clip and choose **Set image as background**, or stretch it to the page edges. Because each clip is full-frame, the text lands in the right spot.
4. Put the matching scrim PNG under the text clip and above your footage. Fade it in and out with Canva's *Fade* animation.
5. Trim the clip to the timing below, or move it freely.

## Clip timings (position in the final film)

| Clip | Starts at | Length |
|---|---|---|
| 00_intro_logo | 0.20 s | 3.40 s |
| 01_made_in_sejong | 4.20 s | 3.63 s |
| 02_dual_function | 8.23 s | 3.10 s |
| 03_key_actives_card | 11.53 s | 3.60 s |
| 04_bio_ferment | 15.50 s | 2.97 s |
| 05_filling_23ml | 18.90 s | 3.07 s |
| 06_tencel_sheet | 22.40 s | 2.93 s |
| 07_sealing | 25.73 s | 2.83 s |
| 08_traceability | 31.80 s | 2.93 s |
| 09_inspection | 35.13 s | 2.90 s |
| 10_product_key_ingredients | 40.93 s | 7.80 s |
| 11_quality_tested | 49.03 s | 3.80 s |
| 12_end_card | 52.77 s | 4.83 s |

## Rebuilding as editable Canva text
The clips can't be edited. To change the wording, rebuild the element as Canva text with these specs.

### Colors

| Use | Hex |
|---|---|
| Headline | `#4A2470` |
| Accent / labels | `#7646A8` |
| Body | `#484258` |
| Lines | `#C4B4E2` |
| Background tint | `#FAF8FD` |

### Fonts and sizes (at 1920×1080)

| Element | Font and size | Notes |
|---|---|---|
| Korean headline | Noto Sans KR (Regular), 64 px | Similar to the film's font, and Canva includes it |
| Korean sub line | Noto Sans KR, 30 px | Body color |
| English label | Inter Medium, 21 px | All caps, letter spacing about 300 |
| Big numbers (2%, 0.04%, 23) | Inter Thin, 120–150 px | |

### Matching Canva animations

| Film effect | Canva animation |
|---|---|
| Headline rising out of a line | **Baseline** |
| English label revealing left to right | **Wipe** |
| Sub line | **Rise** or **Fade** |
| Thin accent line before the label | A line element with **Wipe** |
| Number counters (0 → 2%, 0 → 23ml) | Not available in Canva. Use the WebM clip for these. |

### Safe margins
Text in the film sits at least 130 px from the left and right edges.
